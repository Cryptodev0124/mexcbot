module.exports.Spot = require('./spot')
module.exports.Future = require('./future')
module.exports.Alternative = require('./alternative')