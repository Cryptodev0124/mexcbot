export let globalVariable = "I am a global variable";

export function setGlobalVariable(value) {
    globalVariable = value;
}
